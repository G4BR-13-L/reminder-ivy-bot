import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'not-found',
  templateUrl: './notfound.comp.html',
  styleUrls: ['./notfound.comp.css']
})
export class NotFoundComp {
    constructor(){}
}