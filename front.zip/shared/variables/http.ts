import { enableProdMode } from '@angular/core';

import { environment } from 'src/environments/environment';

let url = 'http://127.0.0.1';

if (environment.production) {
   url = ''
}


export const HTTP_URL = url;