import { AfterViewInit, Directive, ElementRef, Input, OnDestroy } from '@angular/core';
import { DomHandler } from 'primeng/dom';

@Directive({
    selector: '[pIcon]'
})
export class PrimeIcon implements AfterViewInit, OnDestroy {
    constructor(
        private el: ElementRef,
    ) {}

    _initialStyleClass: string;

    @Input() iconPos: 'left' | 'right' | 'top' | 'bottom' = 'left';

    _icon: string;

    public name = 'none'

    @Input() set pIcon(name){
        this.name = name
    }

    @Input() get icon(): string {
        return this._icon;
    }

    set icon(val: string) {
        this._icon = val;
        
        if (this.initialized) {
                DomHandler.findSingle(this.el.nativeElement, '.p-button-icon').className = 'p-button-icon ' + this._icon;

            this.setStyleClass();
        }
    }

    _label: string;

    @Input() get label(): string {
        return this._label;
    }

    set label(val: string) {
        this._label = val;
        
        if (this.initialized) {
            DomHandler.findSingle(this.el.nativeElement, '.p-button-label').textContent = this._label || '&nbsp;';
            this.setStyleClass();
        }
    }

    getStyleClass(): string {
        let styleClass = 'p-button p-component';
        if (this.icon && !this.label) {
            styleClass = styleClass + ' p-button-icon-only';
        }
        
        return styleClass;
    }

    setStyleClass() {
        let styleClass = this.getStyleClass();
        this.el.nativeElement.className = styleClass + ' ' + this._initialStyleClass;
    }

    initialized: boolean = false

    ngAfterViewInit(){
        this._initialStyleClass = this.el.nativeElement.className;

        DomHandler.addMultipleClasses(this.el.nativeElement, this.getStyleClass());

        if (this.icon) {
            let iconElement = document.createElement("span");
            iconElement.className = 'p-button-icon';
            iconElement.setAttribute("aria-hidden", "true");
            let iconPosClass = this.label ? 'p-button-icon-' + this.iconPos : null;
            if (iconPosClass) {
                DomHandler.addClass(iconElement, iconPosClass);
            }
            DomHandler.addMultipleClasses(iconElement, this.icon);
            this.el.nativeElement.appendChild(iconElement);
        }

        this.initialized = true;
    }

    ngOnDestroy() {
        this.initialized = false;
    }
}