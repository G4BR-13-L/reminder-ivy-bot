import { InjectionToken, NgModule } from '@angular/core';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { MultiSelectModule } from 'primeng/multiselect';

import { TableModule } from 'primeng/table';

import { PrimeIcon } from 'src/shared/directives/pIcon';

import { NotFoundComp } from './components/not_found/notfound.comp';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { MyHttpInterceptor } from './services/MyHttpInterceptor';

import { DropdownModule } from 'primeng/dropdown';

import { ToastModule } from 'primeng/toast';

import { CalendarModule } from 'primeng/calendar';

import { SliderModule } from 'primeng/slider';

import { ContextMenuModule } from 'primeng/contextmenu';

import { DialogModule } from 'primeng/dialog';

import { ButtonModule } from 'primeng/button';

import { ProgressBarModule } from 'primeng/progressbar';

import { InputTextModule } from 'primeng/inputtext';

export const Config = new InjectionToken<any>('config');

let DefaultModules = [
  ToastModule,
  
  CalendarModule,

  SliderModule,

  ContextMenuModule,

  DialogModule,

  ButtonModule,

  ProgressBarModule,

  InputTextModule,
  
  TableModule,

  MultiSelectModule,

  DropdownModule,

  HttpClientModule
];

@NgModule({
  declarations: [
    PrimeIcon,
    
    NotFoundComp
  ],

  imports: [
    
  ],

  exports: [
    ...DefaultModules,

    PrimeIcon,

    NotFoundComp,
    
    FormsModule,

    ReactiveFormsModule
  ],

  providers: [
    {provide: HTTP_INTERCEPTORS, useClass: MyHttpInterceptor, multi: true},
    {provide: Config, useValue: {default: 1}, multi: true}
  ]
})
export class SharedModule { }