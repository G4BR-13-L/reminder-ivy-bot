import { Status, status } from '../../interfaces/site.param';
import { map, tap } from 'rxjs/operators';
import { SiteConfig } from './../../services/site_conf/siteconf.service';
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router, Route, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable()
export class MaintenanceGuard implements CanActivate {
    constructor(
        private siteConfig: SiteConfig
    ){}

    SiteOnline: status;

    canActivate(): Observable<boolean> | boolean {
        return this.SiteOnline ? this.SiteOnline == 'on' :
         this.siteConfig.getParam('site_online').pipe(
            tap(Param => this.SiteOnline = (Param.value as status)),
            
            map(Param => Param.value == Status.Active)
        );
    }
}