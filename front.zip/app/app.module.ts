import { ProfileService } from './admin/services/profile/profile.service';
import { SiteConfig } from './services/site_conf/siteconf.service';
import { MaintenanceGuard } from './guards/maintenance/maintenance.guard';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { TranslateModule } from '@ngx-translate/core';

import { SharedModule } from 'src/shared/shared.module';

@NgModule({
  declarations: [
    AppComponent
  ],

  imports: [
    BrowserModule,

    AppRoutingModule,

    BrowserAnimationsModule,

    SharedModule,

    TranslateModule.forRoot()
  ],

  providers: [
    SiteConfig,

    ProfileService,

    MaintenanceGuard
  ],

  bootstrap: [AppComponent]
})

export class AppModule { }
