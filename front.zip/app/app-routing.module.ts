import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotFoundComp } from 'src/shared/components/not_found/notfound.comp';
import { MaintenanceGuard } from './guards/maintenance/maintenance.guard';


const routes: Routes = [
    { path: 'admin',
      loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule),
      canActivate: [MaintenanceGuard],
    },

    { path: '', redirectTo: '/admin', pathMatch: 'full' },

    { path: '**', component: NotFoundComp }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
