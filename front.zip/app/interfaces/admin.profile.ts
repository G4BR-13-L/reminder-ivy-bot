import { status } from './site.param';

export interface AccountProfile {
    id: number;

    name: string;

    username: string;

    active: status;
 
    base: number;

    level: string;

    logged: true | false;
}

export interface LoginResult {
    success: boolean;

    profile?: AccountProfile
}

export interface Result {
    success: boolean;
}

export interface Item {
    id: number;

    date: string | Date;

    course: status;

    name: string;

    description: string;
 
    active: number | string;
}

export interface ItensResult {
    total: number;

    itens: Item[];
}