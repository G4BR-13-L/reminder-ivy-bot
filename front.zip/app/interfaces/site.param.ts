export enum Status {
    Active = 'on',

    Offline = 'off'
}

export type status = 'on' | 'off';

export interface SiteParam {
    id: number;
    param: string;
    value: string;
}