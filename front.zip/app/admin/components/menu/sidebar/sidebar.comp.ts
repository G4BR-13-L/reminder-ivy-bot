import { Component, ViewChild, AfterViewInit, ElementRef, Output, EventEmitter, OnDestroy, ChangeDetectionStrategy } from '@angular/core';

let $ = window['jQuery'];

@Component({
    selector: 'sidebar',
    templateUrl: './sidebar.comp.html',
    styleUrls: ['./sidebar.comp.css'],
    changeDetection: ChangeDetectionStrategy.Default
})
  
export class SidebarComponent implements AfterViewInit, OnDestroy {
      constructor(){}

      @ViewChild('sidebar', {read: ElementRef}) sidebar: ElementRef;

      observer: MutationObserver;

      @Output('compacted') isCompact = new EventEmitter<boolean>(false);

      ngAfterViewInit(){
        this.observer = new MutationObserver(Mutations => {
            Mutations.forEach(Mutation => {
                let classList: DOMTokenList = Mutation.target['classList'];
                this.isCompact.emit(classList.contains('is-compact'));
            })
        })

        let config = { 
            attributes: true, 
            attributeFilter: ['class'], 
            childList: false, 
            characterData: false 
        }

        this.observer.observe(this.sidebar.nativeElement, config);
      }

      ngOnDestroy(){
        this.observer.disconnect();
      }
}