import {  map, tap } from 'rxjs/operators';
import { ProfileService } from '../../../services/profile/profile.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
    selector: 'header',
    templateUrl: './header.comp.html',
    styleUrls: ['./header.comp.css']
})
  
export class HeaderComponent implements OnInit {
      constructor(
          private router: Router,
          private profileService: ProfileService
      ){}
      

      AccountName$: Observable<string>;

      ngOnInit(){
          this.AccountName$ = this.profileService.onAccountUpdate().pipe(
              map(Acc => Acc.name)
          )
      }

      logout(){
        this.profileService.logout().subscribe(
            () => this.router.navigate(['/admin', 'login'])
        )
      }
}