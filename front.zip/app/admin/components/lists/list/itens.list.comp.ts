import { ItemService } from 'src/app/admin/services/itens/item.service';
import { Item } from 'src/app/interfaces/admin.profile';
import { Component, OnInit } from '@angular/core';
import { LazyLoadEvent } from 'primeng/api';

@Component({
  selector: 'itens-list',
  templateUrl: './itens.list.comp.html',
  styleUrls: ['./itens.list.comp.css']
})


export class ItensListComponent implements OnInit {
    constructor(
        private itemService: ItemService
    ){}

    loading = true;

    Itens: Item[] = [];

    rows = 10;

    total = 0;

    ValueStatus(status): number {
        let value = status ? status.value : 'off'

        if(value == 'on') return 1

        return 0
    }

    FormatDate(dt: Date): string {
        let YY = dt.getFullYear().toString()

        let mm = (dt.getMonth() + 1).toString()
        mm = mm.length == 2 ? mm : '0' + mm;

        let dd = dt.getDate().toString()
        dd = dd.length == 2 ? dd : '0' + dd;

        return `${YY}-${mm}-${dd}T`
    }

    statuses = [
        {value: 'on', label: 'Ativado'},
        {value: 'off', label: 'Desativado'}
    ]

    loadItens(first, rows, filters = {}){
        this.loading = true

        this.itemService.getList({rows, first, filters}).subscribe(Result => {
            Result.itens.forEach(Item => {
                let srdt = Item.date as string

                Item.date = new Date(parseInt(srdt) * 1000)

                Item.active = Item.active.toString().length > 1 ? 
                    Item.active : (parseInt(Item.active + '') ? 'on' : 'off')

                console.log(Item)
            })

            this.Itens = Result.itens

            this.total = parseInt(Result.total.toFixed())

            this.loading = false
        })
    }

    ngOnInit(){
        this.loadItens(0, this.rows)
    }

    prev = {};

    isDelete = false;

    prevItem(item: Item){
        this.prev = Object.assign({}, item);

        this.isDelete = false;
    }

    private restoreItem(item: Item){
        Object.keys(this.prev).forEach(key => {
            item[key] = this.prev[key]
        })
    }
    
    saveItem(item: Item) {
        let sent = Object.assign({}, item)

        sent.date = this.FormatDate(sent.date as Date)

        this.itemService.update(item.id, sent).subscribe(Result => {
            Result.success ? {} : this.restoreItem(item)
        });
    }

    deleteItem(item){
        this.itemService.delete(item.id).subscribe(Result => 
            Result.success ? item.deleted = true : item.inDelete = false
        )
    }


    lazyLoad(event: LazyLoadEvent){
        let {rows, first, filters} = event

        this.loadItens(first, rows, filters)
    }
}