import { FormGroup, ControlContainer } from '@angular/forms';
import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';

@Component({
    selector: 'itens-info',
    templateUrl: './itens.info.comp.html',
    styleUrls: ['./itens.info.comp.css'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ItensInfo implements OnInit {
    constructor(
        private controlContainer: ControlContainer
    ){}

    form: FormGroup;

    ngOnInit(){
        this.form = this.controlContainer.control as FormGroup;

        console.log(this.form)
    }

    edit = true;

    prev: any = {};

    modalPane = 'info';

    prevData(){
        let { name, course, date, description, active } = this.form.value

        this.prev = { name, course, date, description, active }
    }

    cancel(){
        this.form.patchValue(this.prev)
    }

    paneActive(mode){
        return this.modalPane == mode
    }
}