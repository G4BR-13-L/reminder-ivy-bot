import { ItemService } from 'src/app/admin/services/itens/item.service';
import { Router } from '@angular/router';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
    selector: 'itens-add',
    templateUrl: './itens.add.comp.html',
    styleUrls: ['./itens.add.comp.css'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
  
export class ItensAddComponent implements OnInit {
    constructor(
        private itemService: ItemService,

        private fb: FormBuilder,

        private router: Router
    ){}

    Customer;

    form: FormGroup;

    page = 'data';

    ngOnInit(){
        this.form = this.fb.group({
            name: ['Vazio', [Validators.required]],
            date: [new Date().getTime(), [Validators.required]],
            course: ['Curso', [Validators.required]],
            description: ['Descricao', [Validators.required]],
            active: [true, [Validators.required]]
        })
    }

    FormatDate(dt: Date){
        let YY = dt.getFullYear().toString()

        let mm = (dt.getMonth() + 1).toString()
        mm = mm.length == 2 ? mm : '0' + mm;

        let dd = dt.getDate().toString()
        dd = dd.length == 2 ? dd : '0' + dd;

        return `${YY}-${mm}-${dd}T`
    }

    doRegister(){
        if(!this.form.valid)
            return alert('Preencha corretamente');

        let event = Object.assign({}, this.form.value);

        event.date = this.FormatDate(new Date(event.date))

        this.itemService.register(event).subscribe(Result => {
            let message = 'Evento registrado com succeso';
            if(!Result.success)
                message = 'Falha ao registrar';

            alert(message);

            if(Result.success)
                this.router.navigate(['/admin', 'itens', 'list']);
        });   
    }

    setPage(page){
        this.page = page;
    }
}