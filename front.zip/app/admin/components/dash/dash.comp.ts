import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { HTTP_URL } from 'src/shared/variables/http';

@Component({
  selector: 'dash',
  templateUrl: './dash.comp.html',
  styleUrls: ['./dash.comp.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})


export class DashComponent {
    constructor(
      private dom: DomSanitizer
    ){}

    sandbox = 'allow-forms allow-modals allow-orientation-lock allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-presentation allow-same-origin allow-scripts';
    
    all_screen = 'width: 100%; height: 100%; border: 0; position: relative;';

    url(value: string){
      value = value.replace('$HTTP_URL', HTTP_URL);
      
      return this.dom.bypassSecurityTrustResourceUrl(value);
    }
}