import { AccountProfile } from './../../../interfaces/admin.profile';
import { Router } from '@angular/router';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ProfileService } from 'src/app/admin/services/profile/profile.service';


@Component({
    selector: 'profile',
    templateUrl: './profile.comp.html',
    styleUrls: ['./profile.comp.css'],
    changeDetection: ChangeDetectionStrategy.Default
})
  
export class Profile implements OnInit {
    constructor(
        private profileService: ProfileService,

        private fb: FormBuilder,

        private router: Router
    ){}

    Customer;

    form: FormGroup;

    page = 'personal';

    ngOnInit(){
        this.profileService.getAdmin().subscribe(Admin => {
            if(!Admin.logged)
                return this.router.navigate(['/admin', 'login'])

            let active  = Admin.active ? true : false;

            this.form = this.fb.group({
                name: [Admin.name, [Validators.required]],
                username: [Admin.username, [Validators.required]],
                password: [''],
                active: [active, [Validators.required]],
                base: [1000, [Validators.required]],
            })
        })
    }

    success(){
        this.profileService.getAdmin().subscribe();

        window.history.back()
    }

    doEdit(){
        if(!this.form.valid)
            return alert('Preencha corretamente');

        let admin = this.form.value;

        this.profileService.update(admin).subscribe(Result => {
            let message = 'Perfil atualizado com succeso';
            if(!Result.success)
                message = 'Falha ao atualizar';

            alert(message);

            if(Result.success)
                this.success()
        });   
    }

    setPage(page){
        this.page = page;
    }
}