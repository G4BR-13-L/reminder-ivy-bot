import { FormGroup } from '@angular/forms';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
    selector: 'profile-personal',
    templateUrl: './profile.personal.comp.html',
    styleUrls: ['./profile.personal.comp.css'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProfilePersonal {
    constructor(){}

    @Input('form') form: FormGroup;

    edit = true;

    prev: any = {};

    modalPane = 'personal';

    prevData(){
        let { name, base } = this.form.value;

        this.prev = { name, base };
    }

    cancel(){
        this.form.patchValue(this.prev);
    }

    paneActive(mode){
        return this.modalPane == mode;
    }
}