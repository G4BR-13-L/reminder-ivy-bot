import { FormGroup } from '@angular/forms';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
    selector: 'profile-security',
    templateUrl: './profile.security.comp.html',
    styleUrls: ['./profile.security.comp.css'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProfileSecurity {
    constructor(){}

    @Input('form') form: FormGroup;

    showPass = true;

    modalPane = 'personal';

    dataInvalid(){
        return this.form.get('username').invalid || this.form.get('password').invalid;
    }

    prev: any = {};

    prevData(){
        let { username, password } = this.form.value;

        this.prev = { username, password };
    }

    cancel(){
        this.form.patchValue(this.prev);
    }

    paneActive(mode){
        return this.modalPane == mode;
    }
}