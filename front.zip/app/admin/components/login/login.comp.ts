import { Router } from '@angular/router';
import { ProfileService } from '../../services/profile/profile.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { animate, state, style, transition, trigger } from '@angular/animations';


@Component({
  selector: 'login',
  templateUrl: './login.comp.html',
  styleUrls: ['./login.comp.css'],
  animations: [
      trigger('login', [
          state('ok', style({
              height: '0px'
          })),

          state('fail', style({
              height: '35px'
          })),

          transition('ok <=> fail', [
              animate('0.3s')
          ])
      ])
  ]
})


export class LoginComponent implements OnInit {
    constructor(
        private profileService: ProfileService,

        private router: Router,

        private fb: FormBuilder
    ){}

    loginForm: FormGroup;

    ngOnInit(){
        this.loginForm = this.fb.group({
            login: ['', [Validators.required]],
            password: ['', [Validators.required]]
        });

        this.profileService.isLogged().subscribe(
            Result => Result ? this.okLogin() : {}
        );
    }

    okLogin(){
        this.router.navigate(['/admin', 'dash']);
    }

    statusLogin = 'ok';

    failLogin(){
        this.statusLogin = 'fail';
    }

    isError(control){
        let _ = <FormControl> control;
        return _.dirty && _.invalid;
    }

    doLogin(){
        let user = this.loginForm.get('login').value;
        let pass = this.loginForm.get('password').value;

        this.loginForm.markAsDirty();

        Object.keys(this.loginForm.controls).map(key => 
            this.loginForm.get(key)
        ).forEach(control => control.markAsDirty());

        if(this.loginForm.valid)
            this.profileService.login(user, pass).subscribe(Result => {
                Result.success ? this.okLogin() : this.failLogin();
            })
    }
}