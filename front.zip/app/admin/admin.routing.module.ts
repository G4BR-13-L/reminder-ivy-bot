import { Profile } from './components/profile/profile.comp';
import { LoginComponent } from './components/login/login.comp';
import { AuthGuard } from './guards/auth/auth.guard';
import { AdminComponent } from './admin.comp';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashComponent } from './components/dash/dash.comp';
import { ItensListComponent } from './components/lists/list/itens.list.comp';
import { ItensAddComponent } from './components/lists/add/itens.add.comp';

const routes: Routes = [
    { path: 'login', component: LoginComponent },

    { path: '', component: AdminComponent,
      canActivateChild: [AuthGuard],
      children: [
          { path: 'dash', component: DashComponent },

          { path: 'itens/list', component: ItensListComponent },

          { path: 'itens/add', component: ItensAddComponent },

          { path: 'itens', pathMatch: 'full', redirectTo: 'itens/list'},

          { path: 'profile', component: Profile }
      ]
    },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
