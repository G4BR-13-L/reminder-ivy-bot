import { tap } from 'rxjs/operators';
import { ProfileService } from '../../services/profile/profile.service';
import { Injectable } from '@angular/core';
import { Router, CanActivateChild } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable()
export class AuthGuard implements CanActivateChild {
    constructor(
        private profileService: ProfileService,
        private router: Router
    ){}

    login(){
        this.router.navigate(['/admin', 'login']);
    }

    canActivateChild(): Observable<boolean> | boolean {
        return this.profileService.isLogged().pipe(
            tap(Result => !Result ? this.login() : {})
        );
    }
}