import { Router } from '@angular/router';
import { ProfileService } from './services/profile/profile.service';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'admin',
  templateUrl: './admin.comp.html',
  styleUrls: ['./admin.comp.css']
})


export class AdminComponent implements OnInit {
    constructor(
        private profileService: ProfileService,

        private router: Router
    ){}

    logged = false;

    isCompact = false;

    checkLogin(success: boolean){
        this.logged = success;

        if(!success)
            this.router.navigate(['/admin', 'login'])
    }

    redirect(){
        this.profileService.isLogged().subscribe(Logged => 
            this.checkLogin(Logged)
        )
    }

    ngOnInit(){        
        this.redirect();
    }
}