import { ItemService } from './services/itens/item.service';
import { ProfilePersonal } from './components/profile/personal/profile.personal.comp';
import { ProfileSecurity } from './components/profile/security/profile.security.comp';
import { Profile } from './components/profile/profile.comp';
import { ItensInfo } from './components/lists/add/info/itens.info.comp';
import { ItemStatus } from './pipes/item.status';
import { ItensListComponent } from './components/lists/list/itens.list.comp';
import { SidebarComponent } from './components/menu/sidebar/sidebar.comp';
import { HeaderComponent } from './components/menu/header/header.comp';
import { LoginComponent } from './components/login/login.comp';
import { AdminComponent } from './admin.comp';
import { AdminRoutingModule } from './admin.routing.module';
import { AuthGuard } from './guards/auth/auth.guard';
import { ProfileService } from './services/profile/profile.service';
import { SharedModule } from 'src/shared/shared.module';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { DashComponent } from './components/dash/dash.comp';
import { ItensAddComponent } from './components/lists/add/itens.add.comp';

const components = [
    LoginComponent,

    HeaderComponent,

    SidebarComponent,

    AdminComponent,

    DashComponent,

    ItensListComponent,

    ItensInfo,

    ItensAddComponent,

    ProfileSecurity,

    ProfilePersonal,
    
    Profile
]

const pipes = [
    ItemStatus
]

@NgModule({
    declarations: [
      ...components,

      ...pipes
    ],
  
    imports: [
      CommonModule,

      AdminRoutingModule,
      
      SharedModule
    ],
  
    providers: [
      AuthGuard,
    
      ProfileService,

      ItemService
    ]
  })
  
  export class AdminModule { }