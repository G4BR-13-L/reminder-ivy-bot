import { Item, ItensResult, Result } from 'src/app/interfaces/admin.profile';
import { HTTP_URL } from 'src/shared/variables/http';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';


@Injectable()
export class ItemService {
    constructor(
        private http: HttpClient
    ){}

    getList({first: offset, rows, filters = {}}): Observable<ItensResult>{
        return this.http.post<ItensResult>(`${HTTP_URL}/itens/list`, {offset, rows, filters})
    }

    
    register(client): Observable<Result>{
        return this.http.post<Result>(`${HTTP_URL}/itens/register`, client)
    }

    update(id: number, client: Item){
        return this.http.post<Result>(`${HTTP_URL}/itens/update/${id}`, client)
    }

    delete(id: number){
        return this.http.get<Result>(`${HTTP_URL}/itens/delete/${id}`)
    }
}