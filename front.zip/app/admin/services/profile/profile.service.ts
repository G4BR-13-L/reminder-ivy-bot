import { Result } from 'src/app/interfaces/admin.profile';
import { HTTP_URL } from 'src/shared/variables/http';
import { map, tap } from 'rxjs/operators';
import { AccountProfile, LoginResult } from '../../../interfaces/admin.profile';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { Injectable, OnDestroy } from '@angular/core';

import { HttpClient } from '@angular/common/http';

@Injectable()
export class ProfileService implements OnDestroy {
    constructor(
        private http: HttpClient
    ){}

    private Logged: boolean;

    private accUpdate: BehaviorSubject<AccountProfile> = new BehaviorSubject(null);

    public onAccountUpdate(): Observable<AccountProfile> {
        return this.accUpdate.asObservable()
    }

    private set Admin(Profile: AccountProfile){
        this.Logged = true

        this.accUpdate.next(Profile)
    }

    isLogged(): Observable<boolean> {
        return this.Logged !== undefined ? of(this.Logged) : this.getAdmin().pipe(
            map( Ret => Ret.logged )
        )
    } 

    getAdmin(): Observable <AccountProfile> {
        return this.http.get<AccountProfile>(`${HTTP_URL}/users/get_admin`).pipe(
            tap(
                Result => Result.logged ? this.Admin = Result : this.Logged = false
            )
        )
    }

    login(login, password): Observable<LoginResult> {
        let loginData = { login, password };
        return this.http.post<LoginResult>(`${HTTP_URL}/users/login`, loginData).pipe(
            tap(
                Result => Result.success ? this.Admin = Result.profile : this.Logged = false
            )
        )
    }

    update(admin): Observable<Result>{
        return this.http.post<Result>(`${HTTP_URL}/users/profile_update`, admin).pipe(
            tap(() => this.getAdmin())
        )
    }
    
    logout(): Observable<any> {
        return this.http.get(`${HTTP_URL}/users/logout`).pipe(
            tap(() => this.Logged = false)
        )
    }

    ngOnDestroy() {
        this.accUpdate.complete()
    }
}
