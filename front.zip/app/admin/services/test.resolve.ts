import { Observable, of } from 'rxjs';
import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';

@Injectable()
export class TestResoolve implements Resolve<any> {
    constructor(){}

    resolve(route: ActivatedRouteSnapshot): Observable<any>{
        return of({test: true});
    }
}