import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'itemStatus'})
export class ItemStatus implements PipeTransform {
    transform(value){
        return value == 'on' ||
               value.toString() == '1'
                 ? 'Ativo' : 'Desativado';
    }
}