import { Component, OnInit } from '@angular/core';

import { PrimeNGConfig, Translation } from 'primeng/api';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent implements OnInit {
    constructor(
      private primeConfig: PrimeNGConfig
    ){}

    private translation: Translation = {
        startsWith: 'Comeca com',
        contains: 'Contem',
        notContains: 'Nao contem',
        endsWith: 'Terminam com',
        equals: 'Igual',
        notEquals: 'Diferente',
        noFilter: 'Sem Filtro',
        lt: 'Menor que',
        lte: 'Menor que ou igual a',
        gt: 'Maior que',
        gte: 'Maior que ou igual a',
        is: 'É',
        isNot: 'Nao é',
        before: 'Antes',
        after: 'Depois',
        clear: 'Limpar',
        apply: 'Aplicar',
        matchAll: 'Todos',
        matchAny: 'Qualquer',
        addRule: 'Adicionar Regra',
        removeRule: 'Remover Regra',
        accept: 'Sim',
        reject: 'Nao',
        choose: 'Escolha',
        upload: 'Carregue',
        cancel: 'Cancelar',
        dayNames: ["Domingo", "Segunda", "Terca", "Quarta", "Quinta", "Sexta", "Sabado"],
        dayNamesShort: ["Do", "Seg", "Ter", "Quart", "Qui", "Sex", "Sab"],
        dayNamesMin: ["Do","Se","Ter","Ter","Qua","Qui","Sa"],
        monthNames: ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"],
        monthNamesShort: ["Jan", "Fev", "Mar", "Abr", "Maio", "Jun","Jul", "Ago", "Set", "Out", "Nov", "Dez"],
        today: 'Hoje',
        weekHeader: 'Wk'
    };

    ngOnInit(){
        this.primeConfig.setTranslation(this.translation)
    }

    exportPdf() {
        import("jspdf").then(jsPDF => {
            let xJSPDF: any = jsPDF;
            import("jspdf-autotable").then(x => {
                const doc = new xJSPDF.default(0,0);
                doc.autoTable([], []);
                doc.save('products.pdf');
            })
        })
    }

    exportExcel() {
        import("xlsx").then(xlsx => {
            const worksheet = xlsx.utils.json_to_sheet([]);
            const workbook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
            const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
            this.saveAsExcelFile(excelBuffer, "products");
        });
    }

    saveAsExcelFile(buffer: any, fileName: string): void {
        import("file-saver").then(FileSaver => {
            let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
            let EXCEL_EXTENSION = '.xlsx';
            const data: Blob = new Blob([buffer], {
                type: EXCEL_TYPE
            });
            FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
        });
    }
}