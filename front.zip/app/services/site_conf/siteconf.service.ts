import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { SiteParam } from '../../interfaces/site.param';
import { HTTP_URL } from 'src/shared/variables/http';

@Injectable()
export class SiteConfig {
    constructor(
        private http: HttpClient
    ){}

    getParam(param: String): Observable<SiteParam> {
        return this.http.get<SiteParam>(`${HTTP_URL}/site/config/${param}`);
    }
}
