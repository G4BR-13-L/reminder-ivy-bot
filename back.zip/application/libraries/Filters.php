<?php
class Filters {
	protected $CI;
	
	public function __construct($params = []){
		$this->CI = &get_instance();
	}
	
	private function contains($field, $str){
		if(!is_string($str)) 
			return false;
		
		$this->CI->db->like($field, $str);
	}
	
	private function startsWith($field, $str){
		if(!is_string($str)) 
			return false;
		
		$this->CI->db->like($field, $str, 'after');
	}
	
	private function endsWith($field, $str){
		if(!is_string($str)) 
			return false;
		
		$this->CI->db->like($field, $str, 'before');
	}
	
	private function equals($field, $val){		
		if(!is_string($val) && !is_numeric($val)) 
			return false;
		
		$this->CI->db->where($field, $val);
	}
	
	private function notEquals($field, $str){
		if(!is_string($str)) 
			return false;
		
		$this->CI->db->where("$field !=", $str);
	}
	
	private function in($field, $itens){
		if(!is_array($str)) 
			return false;
			
		$array = [];
		
		foreach($itens as $item){
			if(is_string($item) || is_numeric($item)){
				$array[] = $item;
			}
		}
		
		$this->CI->db->where_in($field, $array);
	}
	
	public function gt($field, $val){
		if(!is_string($val) && !is_numeric($val))
			return false;
		
		$this->CI->db->where("$field >", $val);
	}
	
	public function lt($field, $val){
		if(!is_string($val) && !is_numeric($val))
			return false;
		
		$this->CI->db->where("$field <", $val);
	}
	
	public function gte($field, $val){
		if(!is_string($val) && !is_numeric($val))
			return false;
		
		$this->CI->db->where("$field >=", $val);
	}
	
	public function lte($field, $val){
		if(!is_string($val) && !is_numeric($val))
			return false;
		
		$this->CI->db->where("$field <=", $val);
	}
	
	private function is($field, $val){
		if(!is_string($val))
			return false;
		
		preg_match("/\d{4}-\d{2}-\d{2}/", $val, $matches);
		
		if(sizeof($matches) == 0)
			return false;
		
		$start = $matches[0];
		
		$end = DateTime::createFromFormat('Y-m-d', $start);
		
		$end->add(new DateInterval('P1D'));

		$end = $end->format('Y-m-d');
		
		$this->CI->db->where("DATE_FORMAT($field, '%Y-%m-%d') >=", $start)
					 ->where("DATE_FORMAT($field, '%Y-%m-%d') <", $end);
	}
	
	private function isNot($field, $val){
		if(!is_string($val))
			return false;
		
		preg_match("/\d{4}-\d{2}-\d{2}/", $val, $matches);
		
		if(sizeof($matches) == 0)
			return false;
		
		$start = $matches[0];
		
		$end = DateTime::createFromFormat('Y-m-d', $start);
		
		$end->add(new DateInterval('P1D'));

		$end = $end->format('Y-m-d');
		
		$this->CI->db->where("DATE_FORMAT($field, '%Y-%m-%d') <", $start)
					 ->where("DATE_FORMAT($field, '%Y-%m-%d') >=", $end);
	}
	
	private function after($field, $val){
		if(!is_string($val))
			return false;
		
		preg_match("/\d{4}-\d{2}-\d{2}/", $val, $matches);
		
		if(sizeof($matches) == 0)
			return false;
		
		$start = $matches[0];
		
		$end = DateTime::createFromFormat('Y-m-d', $start);
		
		$end->add(new DateInterval('P1D'));

		$end = $end->format('Y-m-d');
		
		$this->CI->db->where("DATE_FORMAT($field, '%Y-%m-%d') >=", $end);
	}
	
	private function before($field, $val){
		if(!is_string($val))
			return false;
		
		preg_match("/\d{4}-\d{2}-\d{2}/", $val, $matches);
		
		if(sizeof($matches) == 0)
			return false;
		
		$start = $matches[0];
		
		$this->CI->db->where("DATE_FORMAT($field, '%Y-%m-%d') <", $start);
	}
	
	private function applyMode($mode, $field, $value){
		$allowed = [
			'contains', 'startsWith', 'endsWith', 
			'in', 'equals', 'notEquals', 'is', 'isNot',
			'gt', 'lt', 'gte', 'lte','after','before'
		];
				
		if(!in_array($mode, $allowed))
			return false;
				
		$this->$mode($field, $value);
	}
	
	public function apply($filters = []){		
		foreach($filters as $field => $filter){
			if(!isset($filter['matchMode']))
				continue;
				
			$value = $filter['value'];
			$mode = $filter['matchMode'];
			
			preg_match("/^[A-Za-z_]*/", $field, $matches);
			
			if(sizeof($matches) == 0)
				continue;
			
			$field = $matches[0];
			
			if(strlen($field) <= 0)
				continue;
			
			if(is_null($value))
				continue;
			
			if(is_array($value) && count($value) <= 0)
				continue;
				
			if(is_string($value) && strlen($value) <= 0)
				continue;
				
			if(is_numeric($value))
				$value = floatval($value);
			
			$this->applyMode($mode, $field, $value);
		}
	}
}
?>