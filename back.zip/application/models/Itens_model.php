<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Itens_model extends CI_Model {
	
	function __construct() {
		parent::__construct();
		$this->load->library('Filters');
	}
	
	public function getItemById($id){
		$client = $this->db->where('id', $id)
						   ->get('activities');
						 
		if(!$client->num_rows())
			return false;
			
		return $client->row();
	}
	
	public function getTotalItens(){
		$number = $this->db->select('count(id) as number')
						   ->from('activities')
						   ->get();
						   
		return $number->row()->number;
	}
	
	public function getItens($limit, $offset, $filters){		
		$this->filters->apply($filters);
		
		$itens = $this->db->select('*')
		                      ->from('activities')
							  ->limit($limit, $offset)
							  ->order_by('id', 'desc')
							  ->get();
							  
		if(!$itens->num_rows())
			return [];
			
		return $itens->result_array();
	}
	
	
	public function addItem($item){
		return $this->db->insert('activities', $item);
	}
	
	public function updateItem($id, $item){
		$itemid = $this->getItemById($id);
		
		if(!$itemid)
			return false;
						
		$this->db->where('id', $id)
				 ->update('activities', $item);
				 
		return true;
	}
	
	public function deleteItem($id){
		$item = $this->getItemById($id);
		
		if(!$item)
			return false;
		
		$this->db->where('id', $id);
			
		return $this->db->delete('activities');
	}
}
