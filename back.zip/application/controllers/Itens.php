<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Itens extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$this->load->library('Request');
		$this->load->model('Itens_model');
	}
	
	public function index()
	{
		$this->load->view('welcome_message');
	}
	
	public function register(){
		$data = file_get_contents("php://input");
		$data = json_decode($data, true);
		if(!$data) return;
		
		$this->form_validation->set_data($data);
		
		$this->form_validation->set_rules(
			'date', 'date', 'required|min_length[1]'
		);
		
		$this->form_validation->set_rules(
			'course', 'course', 'required'
		);
		
		$this->form_validation->set_rules(
			'name', 'name', 'required'
		);
		
		$this->form_validation->set_rules(
			'description', 'name', 'required'
		);
		
		if(($success = $this->form_validation->run())){
			$item = [
				'active' => $data['active'] ? 1 : 0,
				
				'date' => $data['date'],
				
				'course' => $data['course'],
				
				'name' => $data['name'],
								
				'description' => $data['description']
			];
			
			$success = $this->Itens_model->addItem($item);
		}
		
		echo json_encode(['success' => $success]);
	}
	
	public function update($id){
		$data = file_get_contents("php://input");
		$data = json_decode($data, true);
		if(!$data) return;
		
		$this->form_validation->set_data($data);
		
		$this->form_validation->set_rules(
			'active', 'active', 'required'
		);
		
		$this->form_validation->set_rules(
			'date', 'date', 'required|min_length[1]'
		);
		
		$this->form_validation->set_rules(
			'course', 'course', 'required'
		);
		
		$this->form_validation->set_rules(
			'name', 'name', 'required'
		);
		
		$this->form_validation->set_rules(
			'description', 'name', 'required'
		);
				
		if(($success = $this->form_validation->run())){
			$item = [
				'active' => $data['active'] == 'on' ? 1 : 0,
				
				'date' => $data['date'],
				
				'course' => $data['course'],
				
				'name' => $data['name'],
								
				'description' => $data['description']
			];
						
			$success = $this->Itens_model->updateItem($id, $item);
		}
		
		echo json_encode(['success' => $success]);
	}
	
	
	public function delete($id){
		$success = $this->Users_model->deleteItem($id);
		
		echo json_encode(['success' => $success]);
	}
	
	public function list(){
		$data = file_get_contents("php://input");
		$data = json_decode($data, true);
		if(!$data) return;
		
		$this->form_validation->set_data($data);
		
		$this->form_validation->set_rules(
			'offset', 'offset', 'required|min_length[0]'
		);
		
		$this->form_validation->set_rules(
			'rows', 'rows', 'required|min_length[1]|max_length[50]'
		);
		
		if(($success = $this->form_validation->run())){
			$limit = $data['rows'];
			
			$offset = $data['offset'];
			
			$total = $this->Itens_model->getTotalItens();
			
			$filters = is_array($data['filters']) ? $data['filters'] : [];
			
			$itens = $this->Itens_model->getItens($limit, $offset, $filters);
		
			foreach($itens as $key => $item){
				$dateTime = new DateTime($item['date']);

				$date = $dateTime->format('U');
				
				$itens[$key]['date'] = $date;
			}
		
			$data = ['total' => intval($total), 'itens' => $itens];
		}
		
		if($success)
			echo json_encode($data);
	}
}
